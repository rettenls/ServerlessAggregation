# General Imports
import json
import base64
import hashlib
import time
import sys
from decimal import Decimal

# AWS Import
import boto3

# Project Imports
from functions import *
from constants import *

# Aggregate over leafs
def aggregate_over_leafs(records):
    
    # Initialize Dict
    delta = dict()
    
     # Iterate over Messages
    for record in records:
        
        # Print
        print(record)

        # Add New Image to Aggregate        
        if 'NewImage' in record['dynamodb']:
            newData = record['dynamodb']['NewImage']
            item_id = newData[STATE_TABLE_KEY]['S']
            new_type = newData['Tp']['S']
            new_value = int(newData['Val']['N'])
             # Add to Value for the New Type
            if new_type not in delta:
                delta[new_type] = new_value
            else:
                delta[new_type] += new_value
        else:
            continue
        
        # Subtract Old Image From Aggregate
        if 'OldImage' in record['dynamodb']: 
            oldData = record['dynamodb']['OldImage']
            old_type = oldData['Tp']['S']
            old_value = int(oldData['Val']['N'])

            # Subtract from Value for the Old Type
            if old_type not in delta:
                delta[old_type] = - old_value
            else:
                delta[old_type] -= old_value
            
        # Ensure that one Id is attached - to ensure uniqueness of batch
        if "id_placeholder" not in delta:
            delta["id_placeholder"] = item_id
        
        # Increment Message Count
        if "message_count" not in delta:
            delta["message_count"] = 1
        else:
            delta["message_count"] += 1
            
    return delta

# Aggregate along tree
def aggregate_along_tree(delta):
    
    # Determine aggregation depth
    aggregation_depth = max([key.count(":") for key in delta.keys()])
    
    # Start at max depth and go higher 
    for depth in range(aggregation_depth, 0, -1):
        children = [key for key in delta.keys() if key.count(":") == depth]
        for child in children:
            parent = child[:child.rfind(":")]
            if parent not in delta:
                delta[parent] = delta[child]
            else:
                delta[parent] += delta[child]
                
    return delta

def lambda_handler(event, context):
    
    # Aggregate incoming messages (only over the leafs)
    delta = aggregate_over_leafs(event['Records'])
    
    # If the batch contains only deletes -> Return True
    if not delta:
        print("Skipped batch - no new entries.")
        return True
                
    # Aggregate along the tree
    delta = aggregate_along_tree(delta)

    # Create Message
    message = json.dumps(delta)
    message_hash = hashlib.sha256(message.encode()).hexdigest()
    
    # Write to DDB
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(DELTA_TABLE_NAME)
    
    print(message)
    
    try: # We use a conditional put based on the hash of the entry to ensure we're not accidentally writing one batch twice.
        table.put_item(
            Item={
                MessageHash: message_hash,
                'Timestamp': Decimal(time.time()),
                'Message': message
                },
            ConditionExpression='attribute_not_exists(MessageHash)'
            )
    except Exception as e:
        print("Conditional Put failed. Item with MessageHash " + message_hash + " already exists. Full Exception: " + str(e) + ".")


    success_message = 'Successfully aggregated ' + str(delta["message_count"]) + ' messages and written to DeltaTable. MessageHash: ' + message_hash
    print(success_message)
    return {
        'statusCode': 200,
        'body': json.dumps(success_message)
    }
