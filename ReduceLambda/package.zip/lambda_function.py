# General Imports
import json
import sys
from decimal import Decimal

# AWS Imports
import boto3

# Project Imports
from functions import *
from constants import *

def lambda_handler(event, context):
    
    print(event)
    
    # Initialize Dict for Total Delta
    total_count = dict()

    # Iterate over Messages
    for record in event['Records']:
        
        print(record)
        
        # Aggregate over Batch of Messages the Lambda was invoked with
        if 'NewImage' in record['dynamodb']:
            
            # Load Message to Dict
            message = record['dynamodb']['NewImage']['Message']['S'].replace("'",'"')
            data = json.loads(message)
            
            # Remove id
            del data['id_placeholder']
            
            # Iterate over Entries in Message
            for entry in data:
                if entry not in total_count:
                    total_count[entry] = data[entry]
                else:
                    total_count[entry] += data[entry]
                    
    if total_count:
                    
        #print('Total Delta:', total_count)
        delta_message_count = total_count['message_count']
        
        # Initialize DDB Table
        dynamodb = boto3.resource('dynamodb', region_name=REGION_NAME)
    
        # Read Current Values with one single BatchOperation
        key_list = [{AGGREGATE_TABLE_KEY: ident} for ident in total_count.keys()]
        response = dynamodb.batch_get_item(
            RequestItems = {
                AGGREGATE_TABLE_NAME : {
                    'ConsistentRead' : True,
                    'AttributesToGet': [AGGREGATE_TABLE_KEY, 'Value'],
                    'Keys': key_list
                }
            },
            ReturnConsumedCapacity = 'TOTAL'
        )
        
        #print('Current:', response['Responses'][AGGREGATE_TABLE_NAME])
        
        # Increment Counts
        for entry in response['Responses'][AGGREGATE_TABLE_NAME]:
            ident = entry[AGGREGATE_TABLE_KEY]
            total_count[ident] = Decimal(total_count[ident]) + entry['Value']
        
        # print('Total:', total_count)
        
        # Write New Values with one single BatchOperation
        response = dynamodb.batch_write_item(
            RequestItems = {
                AGGREGATE_TABLE_NAME : [ { 'PutRequest': { 'Item': {AGGREGATE_TABLE_KEY: entry, 'Value': total_count[entry]}}} for entry in total_count.keys()]
            },
            ReturnConsumedCapacity = 'TOTAL'
        )
        
        success_message = 'Successfully updated aggregates with ' + str(delta_message_count) + ' new messages in total.'
    
    else:
        success_message = 'Skipped batch. Did not contain any new entries.'
        
    
    print(success_message)
    return {
        'statusCode': 200,
        'body': json.dumps(success_message)
    }