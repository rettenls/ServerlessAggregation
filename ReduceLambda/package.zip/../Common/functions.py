# General Imports
from time import sleep

# AWS Imports
import boto3

# Batch write with Exponential Backoff
def batch_write_with_exp_backoff(dynamodb, request_items):  
    
    # First Try
    response = dynamodb.batch_write_item(RequestItems = request_items)
    
    # Exponential Backoff
    sleep_cycles = 1
    while response['UnprocessedItems']:
        sleep(0.05 * (sleep_cycles ** 2))
        request_items = response['UnprocessedItems']
        response = dynamodb.batch_write_item(RequestItems = request_items)
        sleep_cycles += 1
        
# Print Progress Bar
def print_progress_bar(progress):
    progress_bar = int(progress / 2) + 1
    print("\r[" + "#" * progress_bar + " " * (50 - progress_bar) + "]   {:.1f}% completed.".format(progress), end = "")