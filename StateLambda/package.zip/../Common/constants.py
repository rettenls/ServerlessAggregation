# General AWS Settings
REGION_NAME = 'eu-central-1'

# Kinesis
KINESIS_STREAM_NAME = 'FruitBasketStream'

# DynamoDB
STATE_TABLE_NAME = 'StateTable'
STATE_TABLE_KEY = 'Id'
DELTA_TABLE_NAME = 'DeltaTable'
DELTA_TABLE_KEY = 'MessageHash'
AGGREGATE_TABLE_NAME = 'AggregateTable'
AGGREGATE_TABLE_KEY = 'Identifier'