# General Imports
import json
import base64
import hashlib
import time
import sys
from decimal import Decimal

# AWS Import
import boto3

# Project Imports
from functions import *
from constants import *

def lambda_handler(event, context):
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(STATE_TABLE_NAME)
    
    print(event)
    
    records = event['Records']
    
    for record in records:
        # Load Record
        data = json.loads(base64.b64decode(record["kinesis"]["data"]).decode("utf-8"))
        
        # Get Entries
        record_id       = data["id"]
        record_type     = data["type"]
        record_value    = data["value"]
        record_version  = data["version"]
        
        print(data)
    
        # Write to DDB: We use a conditional update item to ensure we always have the most recent version
        try:
            table.update_item(
                Key={
                    STATE_TABLE_KEY: record_id
                    },
                UpdateExpression="SET Val = :new_value, Version = :new_version, Tp = :new_type",
                ConditionExpression='attribute_not_exists(Id) OR Version < :new_version',
                ExpressionAttributeValues={
                    ':new_version': record_version,
                    ':new_value':   record_value,
                    ':new_type':    record_type
                    },
                )
        except Exception as e:
            print("Conditional put failed. This is either a duplicate or a more recent version already arrived.")
      
    
   
    return {
        'statusCode': 200,
        'body': json.dumps('')
    }
