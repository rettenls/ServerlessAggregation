sudo pip3 install influxdb -t .
